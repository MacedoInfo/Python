import cv2
import pytesseract

#passo 1 ler a imagem

imagem = cv2.imread(r"C:\Users\Macedo\Downloads\images.png")
caminho = r"C:\Program Files\Tesseract-OCR" 
#passo 2 pedir pro tesseract extrair o texto da imagem
pytesseract.pytesseract.tesseract_cmd =  caminho + r"\tesseract.exe"
texto = pytesseract.imagem_to_string(imagem)

print(texto)


